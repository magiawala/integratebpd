import LandingPage from "@/imports/LandingPage";

export default function App() {
  return <LandingPage />;
}
