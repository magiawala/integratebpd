
  # Match Design Elements

  This is a code bundle for Match Design Elements. The original project is available at https://www.figma.com/design/6TuC29NCIsMWbtNQe4Vm6I/Match-Design-Elements.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  